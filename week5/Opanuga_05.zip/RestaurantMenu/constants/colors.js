const Colors = {
    accent500: "#D3D3D3", // 500 is the base level color the less the number the light the color
    primary500: "#FFFFFF"
}

export default Colors;