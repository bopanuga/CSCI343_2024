class Country {
  constructor(id, name, color) {
    this.id = id;
    this.name = name; // country name
    this.color = color; //diff backgorund for countries
  }
}

export default Country;
