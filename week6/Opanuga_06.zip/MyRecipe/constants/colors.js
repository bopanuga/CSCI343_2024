// COMPONNENT FOR THE COLOR SCHEME OF THE RECIPE APP
const Colors = {
    accent500: "#071013",
    accent800: "#23b5d3",
    primary300: "#75abbc",
    primary500: "#071013",
    primary800: "#dfe0e2",
};

export default Colors;
