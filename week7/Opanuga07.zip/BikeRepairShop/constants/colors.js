// RESOURCE FILE FOR STYLING FOR THE COLOR SCHEME OF THE BIKE REPAIR APP
const Colors = {
    accent500: "#d8cab2",
    primary300: "##c76335",
    primary500: "##6a7b8c",
    primary800: "#071013",
};

export default Colors;