// RESOURCE FILE FOR STYLING FOR THE COLOR SCHEME OF THE NEWS APP
const Colors = {
    accent200: "#302e7c",
    accent500: "#ffffff",
    accent800: "#005195",
    primary300o5: "#ffffff",
    primary300: "#ffffff",
    primary500o8: "#414141",
    primary500: "#1c1a4d",
    primar800: "#000000",
};

export default Colors;